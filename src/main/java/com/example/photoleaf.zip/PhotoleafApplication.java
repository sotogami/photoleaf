package com.example.photoleaf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PhotoleafApplication {

    public static void main(String[] args) {
        SpringApplication.run(PhotoleafApplication.class, args);
    }
}