package com.example.photoleaf.Message;

import com.example.photoleaf.User.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface MessageRepository extends JpaRepository<Message, Long> {

    List<Message> findBySenderOrReceiver(User sender, User receiver);
    List<Message> findBySenderAndReceiver(User sender, User receiver);
    List<Message> findBySenderAndReceiverOrReceiverAndSender(User sender, User receiver, User sender2, User receiver2);
}